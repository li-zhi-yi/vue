// 下拉
export const PULL_DOWN_HEIGHT = 100;
export const PULL_DOWN_TEXT_INIT = '再拉，再拉就刷给你看';
export const PULL_DOWN_TEXT_START = '够了啦，松开人家嘛';
export const PULL_DOWN_TEXT_ING = '刷呀刷呀，好累啊，喵^ω^';
export const PULL_DOWN_TEXT_END = '刷新完了哦';

// 上拉
export const PULL_UP_HEIGHT = 50;
export const PULL_UP_TEXT_INIT = '再拉，再拉就加载给你看';
export const PULL_UP_TEXT_START = '够了啦，松开人家嘛';
export const PULL_UP_TEXT_ING = '加呀载呀，好累啊，喵^ω^';
export const PULL_UP_TEXT_END = '加载完了哦';
