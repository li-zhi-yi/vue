<template>
  <div class="search">
    search
  </div>
</template>
<script>
  export default {
    name: 'Search'
  };
</script>
<style lang="scss" scoped>
</style>
