<template>
  <div class="personal">
    personal
  </div>
</template>

<script>

  export default {
    name: 'Personal'
  };
</script>

<style lang="scss" scoped>

</style>
