<template>
  <div class="cart">
    购物车
  </div>
</template>

<script>

  export default {
    name: 'cart'
  };
</script>

<style lang="scss" scoped>

</style>
