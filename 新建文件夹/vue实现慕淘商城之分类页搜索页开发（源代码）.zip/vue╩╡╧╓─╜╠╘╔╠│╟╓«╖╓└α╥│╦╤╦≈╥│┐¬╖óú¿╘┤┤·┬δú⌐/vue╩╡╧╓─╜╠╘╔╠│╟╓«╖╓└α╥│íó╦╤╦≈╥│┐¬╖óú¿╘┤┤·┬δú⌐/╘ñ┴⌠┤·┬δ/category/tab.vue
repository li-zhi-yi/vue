<template>
  <div>
    tab
  </div>
  <!--<me-scroll>
    <ul class="tab">
      <li class="tab-item"></li>
    </ul>
  </me-scroll>-->
</template>

<script>
  import MeScroll from 'base/scroll';
  

  export default {
    name: 'CategoryTab',
    components: {
      MeScroll
    }
    
  };
</script>

<style lang="scss" scoped>
 
</style>
